#!/usr/bin/env bash

cd internal
make clean && make
